﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Globalization;

public partial class DefaultCalendar : System.Web.UI.Page
{
   /// <summary>
   /// Default page loage event that is auto generated for the website.
   /// </summary>
   /// <param name="sender"></param>
   /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// The Date Calendar event control. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void txtSelectedDate_TextChanged(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// This event populates the selected date into the textbox control and adds additional 1 day into a user selected date.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void clrDateCalendar_SelectionChanged(object sender, EventArgs e)
    {
        //Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        DateTime strDate = clrDateCalendar.SelectedDate;
        lblMessage.Text = "Your selected date and increment value is :";
        lblMessage.ForeColor = System.Drawing.Color.DarkGreen;
        txtSelectedDate.Text = strDate.AddDays(1).ToShortDateString();
        
    }
}